<?php

class Cliente {

    public $nome;
    public $end;
    public $tel;

    function getNome(){
        
    }

    function getEndereco(){
        
    }

    function getTelefone(){
        
    }
}

$cli = new Cliente;
$cli1 = new Cliente;
$cli2 = new Cliente;
$cli3 = new Cliente;
$cli4 = new Cliente;
$cli5 = new Cliente;


$cli->getNome();
$cli->getEndereco();
$cli->getTelefone();


?>