<?php
$var = 3;
$var2 = 5;

echo ($var > $var2) ? ("true") : ("false");

?>