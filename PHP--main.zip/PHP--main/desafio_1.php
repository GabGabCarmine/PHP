<?php

for ($i = 0; $i <= 10; $i++) { 
    if ($i == 7) {
        print "";
    } else {
        print $i;
    }
}