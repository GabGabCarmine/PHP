<?php

$n = 14;

if ($n % 2 == 0) {
    print "É par!";
} else {
    print "É ímpar!";
}