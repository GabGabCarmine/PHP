<?php

$i = 0;

do{
    print ++$i;
} while ($i < 10);