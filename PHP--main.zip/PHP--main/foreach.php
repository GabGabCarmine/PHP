<?php

$vetor = array (1,2,3,4,5);

foreach ($vetor as $v) {
    print "O valor atual do vetor é $v . <br>";
}