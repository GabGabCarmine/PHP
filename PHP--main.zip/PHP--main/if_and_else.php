<?php

$a = 9;
$b = 10;

if ($a > $b) {
    echo "É maior!";
} else {
    echo "É menor!";
}
