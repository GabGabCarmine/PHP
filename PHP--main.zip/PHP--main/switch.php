<?php

$a = 9;

switch ($a) {
    case 10:
        print  "igual a 10";
        break;
    case 12:
        print "igual a 12";
        break;
    case 13:
        print "igual a 13";
        break;
    default: 
        print "nenhum valor";
        break;
}