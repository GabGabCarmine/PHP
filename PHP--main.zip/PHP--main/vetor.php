<?php

$cor [1] = "vermelho";
$cor [2] = "verde";
$cor [3] = "azul";
$cor ["teste"] = 1;

var_dump($cor);
?>