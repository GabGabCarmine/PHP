<?php

$a = 1;

while ($a < 3) {
    print "menor que 3 <br>";
    $a++;
}

print "igual a 3";